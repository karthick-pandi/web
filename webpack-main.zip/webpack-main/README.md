# webpack
create webpack assignment

Webpack and Babel Pending
Problem
Create a simple note taking web application with HTML/CSS/JS
user should be able take a simple note, and it should be seen on ui.
application should have a logo at top. import this logo in JS. bundle it through webpack
Bundle the other things like CSS, (fonts or icons if you have) with Webpack.
final output should work with bundled code from build folder
Submission Image/Video Instructions
Screenshot of page with network tab open that shows assets coming over network
